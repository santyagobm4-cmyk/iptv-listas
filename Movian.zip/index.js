var plugin = require('movian/plugin');
var page = require('movian/page');
var service = require('movian/service');

plugin.createService(
  "Mi Plugin Bacano",
  "miplugin:start",
  "video",
  true,
  plugin.path + "logo.png"
);

service.create("Mi Plugin Bacano", "miplugin:start", "video", true);

page.Route("miplugin:start", function(page) {
  page.metadata.title = "Mi Plugin Bacano";
  page.metadata.logo = plugin.path + "logo.png";

  page.appendItem("miplugin:tv", "directory", {
    title: "📺 Canales"
  });

  page.appendItem("miplugin:peliculas", "directory", {
    title: "🎬 Películas"
  });

  page.appendItem("miplugin:series", "directory", {
    title: "📺 Series"
  });

  page.loading = false;
});
